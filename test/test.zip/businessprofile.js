$(document).ready(function() {
 

    $(".chosen").chosen({
        search_contains: true,
      inherit_select_classes: true
    });
});