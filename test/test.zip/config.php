<?php
define('DBUSER','root');
define('DBPWD','');
define('DBHOST','localhost');
define('DBNAME','sportsreg');

?>