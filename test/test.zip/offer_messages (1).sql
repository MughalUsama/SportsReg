-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2021 at 01:37 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sportsreg`
--

-- --------------------------------------------------------

--
-- Table structure for table `offer_messages`
--

CREATE TABLE `offer_messages` (
  `message_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `club_id` int(11) NOT NULL,
  `message` varchar(200) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `request_id` int(11) NOT NULL,
  `sentby` int(11) NOT NULL COMMENT '0 for club, 1 for business',
  `status` int(11) NOT NULL DEFAULT 0,
  `is_seen` int(11) NOT NULL DEFAULT 0 COMMENT 'O for unseen,1 for seen'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `offer_messages`
--

INSERT INTO `offer_messages` (`message_id`, `business_id`, `club_id`, `message`, `datetime`, `request_id`, `sentby`, `status`, `is_seen`) VALUES
(1, 12, 8, 'Hello mister', '2021-01-13 16:09:39', 16, 1, 1, 1),
(2, 12, 8, 'Hi!', '2021-01-13 16:14:11', 16, 0, 1, 0),
(3, 12, 8, 'my offer', '2021-01-13 16:23:50', 17, 1, 1, 1),
(4, 12, 8, 'your offer>?\n', '2021-01-13 16:24:16', 17, 0, 1, 1),
(5, 12, 8, 'abc', '2021-01-13 16:59:50', 20, 1, 1, 1),
(6, 12, 8, 'fsdknsl', '2021-01-13 17:00:04', 20, 0, 1, 1),
(7, 12, 8, 'lskfn', '2021-01-13 17:03:37', 20, 0, 1, 1),
(8, 12, 8, 'lsdkfnkn\n', '2021-01-13 17:04:00', 20, 0, 1, 1),
(9, 12, 8, 'ok', '2021-01-13 17:06:06', 20, 1, 1, 1),
(10, 12, 8, 'okkkkkk\n', '2021-01-13 17:06:29', 20, 1, 1, 1),
(11, 12, 8, 'test', '2021-01-13 17:06:50', 20, 0, 1, 1),
(12, 12, 8, 'yes', '2021-01-13 17:11:23', 20, 1, 1, 1),
(13, 12, 8, '....', '2021-01-13 17:14:47', 20, 0, 1, 1),
(14, 12, 8, 'lm;xdvm\n', '2021-01-13 17:16:21', 20, 1, 1, 1),
(15, 12, 8, 'lsdfnkl', '2021-01-13 17:16:41', 20, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `offer_messages`
--
ALTER TABLE `offer_messages`
  ADD PRIMARY KEY (`message_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `offer_messages`
--
ALTER TABLE `offer_messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
